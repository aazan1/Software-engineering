<?php


// Create connection
$conn = new mysqli('localhost', 'root', '', 'se');

// Check connection
if ($conn->connect_error) {
    echo"dssd";

}
else{

    // Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // SQL to insert data into the database
    $sql = "INSERT INTO person (username, emal, password) VALUES ('$username', '$email', '$password')";

    if ($conn->query($sql) === TRUE) {

        echo "<div id='message'>Signup successful!</div>";
        header("Location: login.php");

    } else {
        // Inform the user about error in signup
        echo "<div id='message'>Error signing up. Please try again.</div>";
    }
}
}

// Close connection
$conn->close();
?>