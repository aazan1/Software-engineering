<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Carpooling Service</title>
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background-color: #ccc; /* Changed background color to grey */
    }
    .container {
        max-width: 1000px; /* Increased max-width */
        margin: 20px auto;
        padding: 20px;
        background-color: #fff;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    h1 {
        text-align: center;
        margin-bottom: 30px;
    }
    .options {
        display: flex;
        justify-content: space-between;
        flex-wrap: wrap;
    }
    .option {
        width: 45%;
        margin-bottom: 20px;
        padding: 20px;
        background-color: #f0f0f0;
        border-radius: 8px;
        box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        text-align: center;
    }
    .option:hover {
        transform: translateY(-5px);
        transition: transform 0.3s ease-in-out;
    }
    .option h2 {
        margin-top: 0;
    }
    .option img {
        max-width: 100%;
        height: auto;
        margin-bottom: 10px;
        cursor: pointer; /* Add cursor pointer for better UX */
    }
</style>
</head>
<body>
<div class="container">
    <h1>Welcome to your dashboard</h1>
    <div class="options">
        <div class="option">
            <a href="customerSupport.html">
                <img src="img4.jpeg" alt="Contact Customer">
            </a>
            <h2>Contact Customer</h2>
            <p>Get in touch with our customer service.</p>
        </div>
        <div class="option">
            <a href="tutorial.html">
                <img src="view_tutorials.jpeg" alt="View Tutorials">
            </a>
            <h2>View Tutorials</h2>
            <p>Access our educational tutorials.</p>
        </div>
        <div class="option">
            <a href="viewAll.php">
                <img src="view_all.jpeg" alt="See Accounts">
            </a>
            <h2>See Accounts/Add Acc</h2>
            <p>View your accounts or add a new one.</p>
        </div>
        <div class="option">
            <a href="2FactorA.php">
                <img src="enable_2factor.png" alt="Enable 2 Factor">
            </a>
            <h2>Enable 2 Factor</h2>
            <p>Enhance security with two-factor authentication.</p>
        </div>
        <div class="option">
            <a href="quiz.html">
                <img src="take_quizzes.jpeg" alt="Take Quizzes">
            </a>
            <h2>Take Quizzes</h2>
            <p>Test your knowledge with our quizzes.</p>
        </div>
        <div class="option">
            <a href="debt.html">
                <img src="debt_repayment.jpeg" alt="Debt Repayment">
            </a>
            <h2>Debt Repayment</h2>
            <p>Explore strategies for debt repayment.</p>
        </div>
        <div class="option">
            <a href="tailored_plan.html">
                <img src="visual_learning.jpeg" alt="Visual Learning">
            </a>
            <h2>Financial goals</h2>
            <p>achieve your financial goals</p>
        </div>
        <div class="option">
            <a href="investment_options.html">
                <img src="investment_options.jpeg" alt="View Investment Options">
            </a>
            <h2>View Investment Options</h2>
            <p>Explore available investment options.</p>
        </div>
        <div class="option">
            <a href="market_news.php">
                <img src="market.jpeg" alt="View Market Updates">
            </a>
            <h2>View Market Updates</h2>
            <p>Stay informed with the latest market updates.</p>
        </div>
        <div class="option">
            <a href="glossary.html">
                <img src="glossary.jpeg" alt="View Glossary">
            </a>
            <h2>View Glossary</h2>
            <p>Access our financial glossary for terms.</p>
        </div>
    </div>
</div>
</body>
</html>
