<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Financial Infographic</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .container {
            width: 100%;
            max-width: 800px;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        h1 {
            margin: 20px 0;
        }
        #chartContainer {
            width: 80%; /* Adjust the width as needed */
            max-width: 100%;
            margin: 0 auto;
        }
        #chartContainer img {
            max-width: 100%; /* Set the maximum width of the image */
            height: auto; /* Maintain aspect ratio */
        }
        #questionPrompt {
            margin-top: 20px;
        }
        #questionInput {
            padding: 10px;
            margin-top: 10px;
        }
        #submitBtn, #mainMenuBtn {
            padding: 10px 20px;
            margin-top: 10px;
            background-color: #007bff;
            color: #ffffff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        #submitBtn:hover, #mainMenuBtn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Financial Infographic</h1>
        <div id="chartContainer">
            <!-- Include your infographic or chart here -->
             <img src="img2.png" alt="Financial Infographic">
        </div>
        <p id="questionPrompt">What is the value in March?</p>
        <input type="number" id="questionInput" placeholder="Enter your answer">
        <button id="submitBtn" onclick="checkAnswer()">Submit</button>
        <p id="answerFeedback"></p>
        <button id="mainMenuBtn" onclick="goToMainMenu()">Main Menu</button>
    </div>

    <script>
        // Function to check user's answer
        function checkAnswer() {
            var userInput = parseInt(document.getElementById("questionInput").value);
            var correctAnswer = 10; // Example correct answer, replace with actual value from the infographic
            var answerFeedback = document.getElementById("answerFeedback");

            if (!isNaN(userInput)) {
                if (userInput === correctAnswer) {
                    answerFeedback.textContent = "Correct!";
                    answerFeedback.style.color = "green";
                } else {
                    answerFeedback.textContent = "Incorrect. Try again!";
                    answerFeedback.style.color = "red";
                }
            } else {
                answerFeedback.textContent = "Please enter a valid number.";
                answerFeedback.style.color = "red";
            }
        }

        // Function to navigate back to main menu page
       // Function to navigate back to main menu page
    function goToMainMenu() {
    // Redirect to main menu page
    window.location.href = "main.php"; // Replace with your main menu page URL
    }

    </script>
</body>
</html>
