<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Financial Overview</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        form {
            margin-bottom: 20px;
        }
        input[type="text"], input[type="number"] {
            padding: 8px;
            margin-right: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        input[type="submit"] {
            padding: 8px 16px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <h1>Financial Overview</h1>

    <h2>My Accounts</h2>
    <table>
        <thead>
            <tr>
                <th>Bank Name</th>
                <th>Account Number</th>
                <th>Amount</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Connect to the database
            $conn = new mysqli('localhost', 'root', '', 'se');
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Query to fetch account information from the database
            $sql = "SELECT name, acc, amount FROM bank";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // Output data of each row
                while($row = $result->fetch_assoc()) {
                    echo "<tr><td>" . $row["name"] . "</td><td>" . $row["acc"] . "</td><td>" . number_format($row["amount"], 2) . "</td></tr>";
                }
            } else {
                echo "<tr><td colspan='3'>No accounts found.</td></tr>";
            }
            $conn->close();
            ?>
        </tbody>
    </table>

    <!-- Button to navigate to addAccounts.php -->
    <form action="addAccounts.php">
        <input type="submit" value="Click here to add more accounts">
    </form>

    <!-- Button to go back to main.php -->
    <form action="main.php">
        <input type="submit" value="Go back to Main">
    </form>
</body>
</html>
