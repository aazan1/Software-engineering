<?php
session_start();

// Create connection
$conn = new mysqli('localhost', 'root', '', 'se');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the submitted username and password from the form
    $submitted_username = $_POST['username'];
    $submitted_password = $_POST['password'];

    // Get the username and password from the session
    $saved_username = $_SESSION['username'];
    $saved_password = $_SESSION['password'];

    // Compare the submitted username and password with the ones from the session
    if ($submitted_username == $saved_username && $submitted_password == $saved_password) {
        // Insert record into authen table
        $sql = "INSERT INTO authen (username, authen) VALUES ('$saved_username', 'true')";
        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Successfully activated.'); window.location.href = 'main.php';</script>";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        // Authentication failed, display an error message
        echo "<script>alert('Invalid username or password. Please try again.');</script>";
    }
}

// Close connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>2-Factor Authentication</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
            position: relative; /* Added positioning */
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333333;
        }

        input[type="text"],
        input[type="password"],
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin: 8px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #4caf50;
            color: #fff;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        .back-button {
            position: absolute; /* Positioned relative to its containing form */
            bottom: -40px; /* Adjust as needed */
            left: 50%;
            transform: translateX(-50%);
            display: block;
            text-align: center;
            text-decoration: none;
            color: #333333;
            background-color: #f0f0f0;
            padding: 8px 16px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .back-button:hover {
            background-color: #e0e0e0;
        }
    </style>
</head>
<body>
    <form action="2FactorA.php" method="POST">
        <h2>2-Factor Authentication</h2>
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <input type="submit" value="Submit">
        <!-- Back button inside the form -->
        <a href="main.php" class="back-button">Back to Main Page</a>
    </form>
</body>
</html>
