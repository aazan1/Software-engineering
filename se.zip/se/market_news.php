<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Market News Updates</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .container {
            width: 90%;
            max-width: 600px;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
            color: #333333;
        }
        .news {
            margin-bottom: 20px;
        }
        .news-item {
            padding: 10px;
            background-color: #f2f2f2;
            border-radius: 4px;
            margin-bottom: 10px;
        }
        .navigation {
            text-align: center;
        }
        .next-button, .menu-button {
            padding: 10px 20px;
            background-color: #007bff;
            color: #ffffff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .next-button:hover, .menu-button:hover {
            background-color: #0056b3;
        }
        .news-image {
            max-width: 100%;
            height: auto;
            margin-bottom: 10px;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Market News Updates</h1>
        
        <div class="news">
            <div class="news-item" id="newsItem">
                <img class="news-image" src="image1.jpg" alt="Image 1">
                <p>Stock markets reached new highs today due to positive earnings reports.</p>
            </div>
        </div>

        <div class="navigation">
            <button class="next-button" onclick="nextNews()">Next</button>
            <button class="menu-button" onclick="goToMainMenu()">Main Menu</button>
        </div>
    </div>

    <script>
        // Sample market news updates
        var marketNews = [
            { text: "Stock markets reached new highs today due to positive earnings reports.", image: "mar.jpeg" },
            { text: "Federal Reserve announced an interest rate hike to curb inflation.", image: "mar.jpeg" },
            { text: "Cryptocurrency prices surged as major companies announced plans to accept them as payment.", image: "mar.jpeg" },
            { text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.", image: "mar.jpeg" },
            { text: "Ut porttitor turpis in nisl sagittis ultricies.", image: "mar.jpeg" },
            { text: "Vestibulum a libero ac libero eleifend posuere ut nec risus.", image: "mar.jpeg" },
            { text: "Donec eget nunc ut mi fermentum finibus.", image: "mar.jpeg" },
            { text: "Praesent volutpat eros non vehicula fringilla.", image: "mar.jpeg" },
            { text: "Aliquam erat volutpat. Nunc et dui sit amet eros fermentum lobortis.", image: "mar.jpeg" }
        ];

        var currentNewsIndex = 0;
        var newsItem = document.getElementById("newsItem");

        // Function to display the next news update
        function nextNews() {
            currentNewsIndex = (currentNewsIndex + 1) % marketNews.length;
            updateNews();
        }   

        // Function to update the displayed news update
        function updateNews() {
            var news = marketNews[currentNewsIndex];
            var html = '<img class="news-image" src="' + news.image + '" alt="Image">' +
                       '<p>' + news.text + '</p>';
            newsItem.innerHTML = html;
        }

        // Function to navigate back to main menu page
        function goToMainMenu() {
            // Redirect to main menu page
            window.location.href = "main.php"; // Replace with your main menu page URL
        }

        // Display the first news update on page load
        updateNews();
    </script>
</body>
</html>
