<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Accounts</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        form {
            margin-bottom: 20px;
            background-color: #ffffff;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        input[type="text"], input[type="number"] {
            padding: 10px;
            margin-right: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            width: 100%;
            box-sizing: border-box; /* Ensure the padding is included in the width */
        }
        input[type="submit"] {
            padding: 10px 16px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
        .error {
            color: #ff0000;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <h1>Add Accounts</h1>

    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <input type="text" name="name" placeholder="Bank Name" pattern="[A-Za-z]+" title="Bank name must only contain alphabetic characters" required>
        <input type="text" name="acc" placeholder="Account Number (e.g., ABC12345)" pattern="[A-Za-z0-9]{8}" title="Account number must be 8 characters long and contain only alphabetic characters and numbers" required>
        <input type="number" name="amount" placeholder="Amount (e.g., 12.25)" required>
        <input type="submit" value="Add Account">
    </form>

    <?php
    // Add new account to the database when form is submitted
    session_start();

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $saved_username = $_SESSION['username'];
        $name = $_POST["name"];
        $acc = $_POST["acc"];
        $amount = $_POST["amount"];

        // Check if amount is numeric and greater than or equal to 0.00
        if (!is_numeric($amount) || $amount < 0) {
            echo "<p class='error'>Amount must be a numeric value greater than or equal to 0.00.</p>";
        } else {
            // Connect to the database
            $conn = new mysqli('localhost', 'root', '', 'se');
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Check if account number already exists
            $check_query = "SELECT COUNT(*) AS count FROM bank WHERE acc = '$acc'";
            $check_result = $conn->query($check_query);
            $row = $check_result->fetch_assoc();
            $count = $row['count'];
            if ($count > 0) {
                echo "<p class='error'>Account number already exists.</p>";
            } else {
                // Check if amount is positive
                if ($amount >= 0) {
                    // Prepare and bind the statement
                    $stmt = $conn->prepare("INSERT INTO bank (name, acc, amount, usernames) VALUES (?, ?, ?, ?)");
                    $stmt->bind_param("ssds", $name, $acc, $amount, $saved_username);

                    // Execute the statement
                    if ($stmt->execute() === TRUE) {
                        echo "<p>New account added successfully.</p>";
                    } else {
                        echo "<p class='error'>Error: " . $stmt->error . "</p>";
                    }

                    // Close the statement
                    $stmt->close();
                } else {
                    echo "<p class='error'>Amount must be a positive value.</p>";
                }
            }

            // Close the connection
            $conn->close();
        }
    }
    ?>

    <!-- Button to go back to main.php -->
    <form action="main.php">
        <input type="submit" value="Go back to Main">
    </form>
</body>
</html>
